<?php
/**
 * @file
 * controls load theme.
 */

require_once drupal_get_path('theme', 'nucleus') . '/inc/theme_function_overrides.inc';
require_once drupal_get_path('theme', 'nucleus') . '/inc/custom_functions.inc';
require_once drupal_get_path('theme', 'nucleus') . '/inc/preprocess_functions.inc';
require_once drupal_get_path('theme', 'nucleus') . '/inc/alters.inc';

/**
 * Implements hook_theme().
 */
function nucleus_theme() {
  $items = array();
  $items ['fieldset'] = array(
    'arguments' => array(
      'element' => array(),
    ),
    'template' => 'fieldset',
    'path' => drupal_get_path('theme', 'nucleus') . '/tpl',
  );
  // Split out pager list into separate theme function.
  $items ['pager_list'] = array(
    'arguments' => array(
      'tags' => array(),
      'limit' => 10,
      'element' => 0,
      'parameters' => array(),
      'quantity' => 9,
    ),
  );

  $items['render_panel'] = array(
    "variables" => array(
      'page' => array(),
      'panels_list' => array(),
      'panel_regions_width' => array(),
    ),
    'preprocess functions' => array(
      'nucleus_preprocess_render_panel',
    ),
    'template' => 'panel',
    'path' => drupal_get_path('theme', 'nucleus') . '/tpl',
  );
  return $items;
}
